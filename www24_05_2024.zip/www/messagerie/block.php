<?php
session_start();
include '../include/database.php';

// Récupérer l'ID de l'utilisateur actuel
$current_user_id = $_SESSION['user']['id'];

// Gestion du blocage/déblocage d'un contact dans la messagerie
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contact_id = $_POST['user_id'];
    
    // Vérifier le statut actuel de blocage
    $query = $db->prepare("SELECT blocage FROM messagerie WHERE (id1 = :current_user_id AND id2 = :contact_id) OR (id1 = :contact_id AND id2 = :current_user_id)");
    $query->execute(array(':current_user_id' => $current_user_id, ':contact_id' => $contact_id));
    $result = $query->fetch();

    if ($result) {
        $new_blocage_status = $result['blocage'] == 1 ? 0 : 1;
        // Mettre à jour le champ blocage
        $update_query = $db->prepare("UPDATE messagerie SET blocage = :new_blocage_status WHERE (id1 = :current_user_id AND id2 = :contact_id) OR (id1 = :contact_id AND id2 = :current_user_id)");
        $update_query->execute(array(':new_blocage_status' => $new_blocage_status, ':current_user_id' => $current_user_id, ':contact_id' => $contact_id));
        ?>
            <br />
            <br />
            <br />
        <?php
        echo '<div class="message">';
        echo $new_blocage_status == 1 ? "Conversation bloquée avec succès." : "Conversation débloquée avec succès.";
        echo '</div>';
    }
}

// Récupérer la liste des utilisateurs avec lesquels l'utilisateur a interagi
$users_query = $db->prepare("SELECT u.id, u.Nom, u.Prenom FROM utilisateur u INNER JOIN messagerie m ON (u.id = m.id1 OR u.id = m.id2) WHERE (m.id1 = :current_user_id OR m.id2 = :current_user_id) AND u.id != :current_user_id GROUP BY u.id, u.Nom, u.Prenom");
$users_query->execute(array(':current_user_id' => $current_user_id));
$users = $users_query->fetchAll(PDO::FETCH_ASSOC);

// Récupérer la liste des utilisateurs bloqués par l'utilisateur actuel
$blocked_users_query = $db->prepare("SELECT u.id, u.Nom, u.Prenom FROM utilisateur u INNER JOIN messagerie m ON ((u.id = m.id1 AND m.id2 = :current_user_id) OR (u.id = m.id2 AND m.id1 = :current_user_id)) WHERE m.blocage = 1 AND (m.id1 = :current_user_id OR m.id2 = :current_user_id) AND u.id != :current_user_id GROUP BY u.id, u.Nom, u.Prenom");
$blocked_users_query->execute(array(':current_user_id' => $current_user_id));
$blocked_users = $blocked_users_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bloquer un utilisateur - RencontreProfs</title>
    <link rel="stylesheet" href="../css/block2.css">
    <link rel="stylesheet" href="../css/retour.css">
</head>
<body>
    <br />
    <br />
    <h1>Bloquer un utilisateur</h1>
    <form method="POST" action="">
        <label for="user_search">Rechercher un utilisateur :</label>
        <input type="text" id="user_search" name="user_search" placeholder="Nom d'utilisateur" required>
        <input type="hidden" id="user_id" name="user_id">
        <button type="submit">Bloquer</button>
    </form>

    <div id="search_results"></div>
    <h2>Liste des utilisateurs bloqués</h2>
    <div id="blocked_user_list">
        <?php if (count($blocked_users) > 0): ?>
            <?php foreach ($blocked_users as $user): ?>
                <div>
                    <?php echo htmlspecialchars($user['Prenom'] . ' ' . htmlspecialchars($user['Nom'])); ?>
                    <form method="POST" action="" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <button type="submit">Débloquer</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucun utilisateur bloqué.</p>
        <?php endif; ?>
    </div>
    <div>
  <!-- Bouton de retour -->
  <button class="back-button" onclick="window.location.href = 'acceuilmessagerie.php?user_id=<?php echo $_SESSION['user']['id']; ?>';">
    <i class="fa fa-arrow-left"></i> Retour
  </button>  
</div>
    <script src='../js/block.js'></script>
</body>
</html>