<?php
// Démarrer la session
session_start();

// Inclure le fichier de base de données
include '../include/database.php';

// Récupérer les ID des utilisateurs depuis l'URL
$user_id = $_GET['user_id'];
$user2_id = $_GET['user2_id'];

// Récupérer les informations de l'utilisateur
$query_user = $db->prepare("SELECT Nom, Prenom, photo FROM utilisateur WHERE id = :id");
$query_user->execute(array(':id' => $user_id));
$user = $query_user->fetch();

// Récupérer les informations de l'utilisateur correspondant (user2_id)
$query_user2 = $db->prepare("SELECT Nom, Prenom, photo FROM utilisateur WHERE id = :id");
$query_user2->execute(array(':id' => $user2_id));
$user2 = $query_user2->fetch();

$filename = "../" . $user["photo"];
$user2_photo = "../" . $user2["photo"];

// Récupérer les contacts ajoutés par l'utilisateur depuis la base de données
$query = $db->prepare("SELECT utilisateur.id, Nom, Prenom, photo FROM utilisateur INNER JOIN messagerie ON utilisateur.id = messagerie.id2 WHERE messagerie.id1 = :user_id ORDER BY Nom, Prenom");
$query->execute(array(':user_id' => $user_id));
$contacts = $query->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les messages échangés entre les deux utilisateurs
$query_messages = $db->prepare("SELECT * FROM message WHERE idconversation = (SELECT idconversation FROM messagerie WHERE (id1 = :user_id AND id2 = :user2_id) OR (id1 = :user2_id AND id2 = :user_id)) ORDER BY ordre");
$query_messages->execute(array(':user_id' => $user_id, ':user2_id' => $user2_id));
$messages = $query_messages->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Messagerie - RencontreProfs</title>
  <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700,300' rel='stylesheet' type='text/css'>
  <script src="https://use.typekit.net/hoy3lrg.js"></script>
  <script>try{Typekit.load({ async: true });}catch(e){}</script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css'>
  <link rel="stylesheet" href="../css/messagerie.css">
  <link rel="stylesheet" href="../css/retour.css">
</head>
<body>
<div id="frame">
  <div id="sidepanel">
    <div id="profile">
      <div class="wrap">
        <?php echo '<img src="' . $filename . '" class="online" width="40" height="40" alt="" />'; ?>
        <p><?php echo $user['Prenom'] . ' ' . $user['Nom']; ?></p>
        <i class="fa fa-chevron-down expand-button" aria-hidden="true"></i>
        <div id="status-options">
          <ul>
            <li id="status-online" class="active"><span class="status-circle"></span> <p>Online</p></li>
            <li id="status-away"><span class="status-circle"></span> <p>Away</p></li>
            <li id="status-busy"><span class="status-circle"></span> <p>Busy</p></li>
            <li id="status-offline"><span class="status-circle"></span> <p>Offline</p></li>
          </ul>
        </div>
        <div id="expanded">
          <label for="facebook"><i class="fa fa-facebook fa-fw" aria-hidden="true"></i></label>
          <input name="facebook" type="text" value="Couscous" />
          <label for="twitter"><i class="fa fa-twitter fa-fw" aria-hidden="true"></i></label>
          <input name="twitter" type="text" value="couscous" />
          <label for="instagram"><i class="fa fa-instagram fa-fw" aria-hidden="true"></i></label>
          <input name="instagram" type="text" value="couscous" />
        </div>
      </div>
    </div>
    <div id="search">
      <label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
      <input type="text" id="search-input" placeholder="Rechercher des personnes..." onkeyup="filterContacts()" />
    </div>
    <div id="contacts">
        <ul id="contacts-list">
        <?php foreach ($contacts as $contact): ?>
            <li class="contact">
                <div class="wrap">
                    <span class="contact-status online"></span>
                    <?php 
                    // Chemin de la photo du contact
                    $contact_photo = "../" . $contact['photo'];
                    echo '<a href="messagerie.php?user_id=' . $user_id . '&user2_id=' . $contact['id'] . '">';
                    echo '<img src="' . $contact_photo . '" class="online" width="40" height="40" alt="" />';
                    echo '</a>';
                    ?>
                    <div class="meta">
                        <p class="name"><?php echo $contact['Prenom'] . ' ' . $contact['Nom']; ?></p>
                        <p class="preview">Envoyez un message à <?php echo $contact['Prenom']; ?></p>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<div id="bottom-bar">
    <button id="addcontact" onclick="window.location.href='demandami.php'"><i class="fa fa-user-plus fa-fw" aria-hidden="true"></i> <span>Ajouter</span></button>
    <button id="block" onclick="window.location.href='block.php'"><i class="fa fa-cog fa-fw" aria-hidden="true"></i> <span>Paramètre</span></button>
</div>
</div>
<div class="content">
    <div class="contact-profile">
      <?php echo '<img src="' . $user2_photo . '" alt="" />'; ?>
      <p><?php echo $user2['Prenom']; ?></p>
      <div class="social-media">
        <i class="fa fa-facebook" aria-hidden="true"></i>
        <i class="fa fa-twitter" aria-hidden="true"></i>
        <i class="fa fa-instagram" aria-hidden="true"></i>
      </div>
    </div>
    <div class="messages">
      <ul>
        <?php foreach ($messages as $message): ?>
            <li class="<?php echo ($message['idtalker'] == $user_id) ? 'sent' : 'replies'; ?>">
                <?php if ($message['idtalker'] == $user_id): ?>
                    <img src="<?php echo $filename; ?>" alt="" />
                <?php else: ?>
                    <img src="<?php echo $user2_photo; ?>" alt="" />
                <?php endif; ?>
                <p><?php echo $message['contenue']; ?></p>
            </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="message-input">
      <div class="wrap">
      <input type="text" id="message-input" placeholder="Écrivez votre message..." />
      <i class="fa fa-paperclip attachment" aria-hidden="true"></i>
      <button class="submit" onclick="sendMessage()"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
      </div>
    </div>
  </div>
</div>
<div>
  <!-- Bouton de retour -->
  <button class="back-button" onclick="window.location.href = 'acceuilmessagerie.php?user_id=<?php echo $_SESSION['user']['id']; ?>';">
    <i class="fa fa-arrow-left"></i> Retour
  </button>  
</div>

<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script>
function filterContacts() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('search-input');
  filter = input.value.toLowerCase();
  ul = document.getElementById("contacts-list");
  li = ul.getElementsByTagName('li');

  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("p")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toLowerCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}

function sendMessage() {
  var messageInput = document.getElementById('message-input');
  var message = messageInput.value;
  if (message.trim() !== '') {
    $.ajax({
      url: 'send_message.php',
      type: 'POST',
      data: {
        user_id: <?php echo $user_id; ?>,
        user2_id: <?php echo $user2_id; ?>,
        message: message
      },
      success: function(response) {
        var messagesUl = document.querySelector('.messages ul');
        var newMessageLi = document.createElement('li');
        newMessageLi.className = 'sent';
        newMessageLi.innerHTML = '<img src="<?php echo $filename; ?>" alt="" /><p>' + message + '</p>';
        messagesUl.appendChild(newMessageLi);
        messageInput.value = '';
        $('.messages').animate({ scrollTop: $('.messages')[0].scrollHeight }, 'fast');
      }
    });
  }
}

$(document).ready(function(){
  $('.messages').animate({ scrollTop: $('.messages')[0].scrollHeight }, 'fast');
});
</script>
</body>
</html>
