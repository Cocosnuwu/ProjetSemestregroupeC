<?php
// Inclure le fichier de base de données
include '../include/database.php';

// Récupérer les données POST
$user_id = $_POST['user_id'];
$user2_id = $_POST['user2_id'];
$message = $_POST['message'];

// Récupérer l'ID de la conversation entre les deux utilisateurs
$query = $db->prepare("SELECT idconversation FROM messagerie WHERE (id1 = :user_id AND id2 = :user2_id) OR (id1 = :user2_id AND id2 = :user_id)");
$query->execute(array(':user_id' => $user_id, ':user2_id' => $user2_id));
$conversation = $query->fetch();

if ($conversation) {
  // Ajouter le nouveau message à la base de données
  $query = $db->prepare("INSERT INTO message (idconversation, idtalker, contenue) VALUES (:idconversation, :idtalker, :contenue)");
  $query->execute(array(':idconversation' => $conversation['idconversation'], ':idtalker' => $user_id, ':contenue' => $message));
  
  echo "Message envoyé!";
} else {
  echo "Erreur: Conversation introuvable.";
}
?>
