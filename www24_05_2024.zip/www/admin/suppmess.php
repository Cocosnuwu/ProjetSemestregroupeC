<?php
// Démarrer la session
session_start();

// Inclure le fichier de base de données
include '../include/database.php';

// Fonction pour récupérer l'ID d'un utilisateur par son nom et prénom
function getUserId($db, $prenom, $nom) {
    $query = $db->prepare("SELECT id FROM utilisateur WHERE Prenom = :prenom AND Nom = :nom");
    $query->execute(array(':prenom' => $prenom, ':nom' => $nom));
    return $query->fetchColumn();
}

$messages = [];
$error_message = '';

// Si le formulaire de recherche est soumis
if (isset($_POST['prenom1']) && isset($_POST['nom1']) && isset($_POST['prenom2']) && isset($_POST['nom2'])) {
    $prenom1 = $_POST['prenom1'];
    $nom1 = $_POST['nom1'];
    $prenom2 = $_POST['prenom2'];
    $nom2 = $_POST['nom2'];

    // Récupérer les ID des utilisateurs
    $user1_id = getUserId($db, $prenom1, $nom1);
    $user2_id = getUserId($db, $prenom2, $nom2);

    if ($user1_id && $user2_id) {
        // Récupérer les messages échangés entre les deux utilisateurs
        $query_messages = $db->prepare("SELECT * FROM message WHERE idconversation = (SELECT idconversation FROM messagerie WHERE (id1 = :user1_id AND id2 = :user2_id) OR (id1 = :user2_id AND id2 = :user1_id)) ORDER BY ordre");
        $query_messages->execute(array(':user1_id' => $user1_id, ':user2_id' => $user2_id));
        $messages = $query_messages->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $error_message = "Un ou les deux utilisateurs n'existent pas.";
    }
}

// Si une suppression de message est demandée
if (isset($_POST['delete_message_id'])) {
    $message_id = $_POST['delete_message_id'];
    $query_delete = $db->prepare("DELETE FROM message WHERE idmessage = :message_id");
    $query_delete->execute(array(':message_id' => $message_id));
    $error_message = "Message supprimé avec succès.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Recherche de Conversations - RencontreProfs</title>
    <link rel="stylesheet" href="../css/suppmess.css">
    <link rel="stylesheet" href="../css/retour.css">
</head>
<body>
<div class="container">
    <h1>Recherche de Conversations</h1>
    <form method="POST" action="">
        <div>
            <label for="prenom1">Prénom de l'utilisateur 1:</label>
            <input type="text" id="prenom1" name="prenom1" required>
        </div>
        <div>
            <label for="nom1">Nom de l'utilisateur 1:</label>
            <input type="text" id="nom1" name="nom1" required>
        </div>
        <div>
            <label for="prenom2">Prénom de l'utilisateur 2:</label>
            <input type="text" id="prenom2" name="prenom2" required>
        </div>
        <div>
            <label for="nom2">Nom de l'utilisateur 2:</label>
            <input type="text" id="nom2" name="nom2" required>
        </div>
        <button type="submit">Rechercher</button>
    </form>
    
    <?php if (!empty($error_message)): ?>
        <p><?php echo $error_message; ?></p>
    <?php endif; ?>

    <?php if (!empty($messages)): ?>
        <h2>Messages de la conversation</h2>
        <ul>
            <?php foreach ($messages as $message): ?>
                <li>
                    <p><?php echo $message['contenue']; ?></p>
                    <form method="POST" action="">
                        <input type="hidden" name="delete_message_id" value="<?php echo $message['idmessage']; ?>">
                        <button type="submit">Supprimer</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
<div>
  <!-- Bouton de retour -->
  <button class="back-button" onclick="window.location.href = '../menuabonne.php'">
    <i class="fa fa-arrow-left"></i> Retour
  </button>  
</div>
</body>
</html>
