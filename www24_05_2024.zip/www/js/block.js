document.getElementById('user_search').addEventListener('input', function() {
            var query = this.value;
            if (query.length > 2) {
                fetch('../messagerie/search_users.php?query=' + query)
                    .then(response => response.json())
                    .then(data => {
                        var results = document.getElementById('search_results');
                        results.innerHTML = '';
                        data.forEach(user => {
                            var div = document.createElement('div');
                            div.textContent = user.Prenom + ' ' + user.Nom;
                            div.dataset.id = user.id;
                            div.addEventListener('click', function() {
                                document.getElementById('user_search').value = this.textContent;
                                document.getElementById('user_id').value = this.dataset.id;
                                results.innerHTML = '';
                            });
                            results.appendChild(div);
                        });
                    });
            }
        });