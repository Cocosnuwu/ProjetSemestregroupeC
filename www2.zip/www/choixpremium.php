<!DOCTYPE html>
<html>

<head>
  <script src="choixdeconnexion.js"> </script>
  <link rel="stylesheet" type="text/css" href="css/inscription.css">

  <head>

  <body>

    <ul>
      <li class="l1"><a href="payement1.php">1 mois pour 5,99 euros </a></li>
      <li class="l1"><a href="payement2.php">3 mois pour 10,99 euros </a></li>
      <li class="active"><a href="payemenent3.php">1 an pour 59,99 euros</a></li>
      </li>
    </ul>
  </body>

</html>