<!DOCTYPE html>
<html>

<head>
  <script src="choixdeconnexion.js"> </script>
  <link rel="stylesheet" type="text/css" href="css/choixdeconnexion.css">

  <head>

  <body>

    <ul>
      <li class="l1"><a href="choixdeconnexion.html">Voici tout ce que vous débloquerez avec notre version premium </a>
      </li>

    </ul>
  </body>

</html>