<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Page de paiement</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">
    <form action="menuabonne.php">
      <div class="row">
        <div class="col">
          <h3 class="title">Adresse de Facturation</h3>
          <div class="inputBox">
            <label for="name">Prénom et NOM :</label>
            <input type="text" id="name" placeholder="Ex : Nicolas DUBOIS" required>
          </div>
          <div class="inputBox">
            <label for="email">Email :</label>
            <input type="text" id="email" placeholder="Ex : carotte@gmail.com" required>
          </div>
          <div class="inputBox">
            <label for="address">Adresse :</label>
            <input type="text" id="address" placeholder="Ex : 30 rue des Tulipes" required>
          </div>
          <div class="inputBox">
            <label for="city">Ville :</label>
            <input type="text" id="city" placeholder="Ex : Paris" required>
          </div>
          <div class="flex">
            <div class="inputBox">
              <label for="state">Département:</label>
              <input type="text" id="state" placeholder="Ex: Ain" required>
            </div>
            <div class="inputBox">
              <label for="zip">Code postal:</label>
              <input type="number" id="zip" placeholder="Ex : 92000" required>
            </div>
          </div>
        </div>
        <div class="col">
          <h3 class="title">Paiement</h3>
          <div class="inputBox">
            <label for="name">Moyens de paiement acceptés :</label>
            <img src="https://w7.pngwing.com/pngs/805/227/png-transparent-paypal-the-next-level-service-payment-gateway-industry-paypal-text-payment-logo-thumbnail.png" alt="credit/debit card image">
          </div>
          <div class="inputBox">
            <label for="cardName">Nom du titulaire de la carte :</label>
            <input type="text" id="cardName" placeholder="Ex : Nicolas DUBOIS" required>
          </div>
          <div class="inputBox">
            <label for="cardNum">Numéro de carte bancaire :</label>
            <input type="text" id="cardNum" placeholder="Ex : 1111-2222-3333-4444" maxlength="19" required>
          </div>
          <div class="inputBox">
            <label for="">Mois :</label>
            <select name="" id="">
              <option value="">Choisir </option>
              <option value="January">Janvier</option>
              <option value="February">Février</option>
              <option value="March">Mars</option>
              <option value="April">Avril</option>
              <option value="May">Mai</option>
              <option value="June">Juin</option>
              <option value="July">Juillet</option>
              <option value="August">Août</option>
              <option value="September">Septembre</option>
              <option value="October">Octobre</option>
              <option value="November">Novembre</option>
              <option value="December">Décembre</option>
            </select>
          </div>
          <div class="flex">
            <div class="inputBox">
              <label for=""> Année :</label>
              <select name="" id="">
                <option value="">Choisir</option>
                <option value="2023">2023</option>
                <option value="2024">2024</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
                <option value="2028">2028</option>
                <option value="2029">2029</option>
                <option value="2030">2030</option>
                <option value="2031">2031</option>
                <option value="2032">2032</option>
                <option value="2033">2033</option>
              </select>
            </div>
            <<div class="inputBox">
              <label for="cvv">CVV :</label>
              <input type="number" id="cvv" placeholder="Ex : 123" required>
            </div>
          </div>
        </div>
      </div>
      <input type="submit" value="Confirmer et Payer 5,99€" class="submit_btn">
      </form>
      <div>
      <button class="back-button" onclick="window.location.href='pub.php'">
        <i class="fa fa-arrow-left"></i> Retour
      </button>

      </div>
    
  </div>
  <script type="text/javascript" src="index.js"></script>
</body>

</html>